# Overview

This is an Android demonstration application built with Kotlin and Jetpack Compose that showcases a polished welcome animation followed by a simulated lock screen interface. The app demonstrates modern Android UI patterns, permission handling, and security simulation without compromising actual device security. Users experience a smooth "Hello" animation with particle effects, transparent permission requests, and a fullscreen PIN entry interface requiring the code `123456`.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Application Structure
The app follows standard Android architecture with two main activities:
- **MainActivity**: Handles splash screen animation and permission flow
- **LockActivity**: Provides fullscreen PIN entry simulation

## UI Framework
- **Jetpack Compose**: Modern declarative UI framework for all screens
- **Material3 Design**: Latest Material Design system for consistent theming
- **Custom Animations**: Smooth transitions, fade-in effects, and particle animations

## Permission Management
- **Transparent Permission Flow**: Clear explanations before requesting permissions
- **Standard Android APIs**: Uses native permission dialogs without bypassing security
- **Graceful Handling**: Proper error states when permissions are denied

## Lock Screen Simulation
- **App-Level Security**: PIN protection within the app only, not system-level
- **Hardcoded PIN**: Demo uses `123456` as the unlock code
- **Navigation Control**: Back button disabled only during lock screen activity
- **Screen Management**: Keeps screen awake during lock activity without modifying system settings

## Design Patterns
- **Activity-Based Navigation**: Clear separation between splash/permissions and lock screen
- **State Management**: Compose state handling for UI updates and animations
- **Material3 Theming**: Consistent color schemes and component styling
- **Accessibility**: High contrast text and large tap targets

# External Dependencies

## Core Android Dependencies
- **Jetpack Compose**: UI framework and animation system
- **Material3**: Design system and component library
- **Android SDK 34+**: Target platform with modern APIs

## Optional Animation Libraries
- **Lottie** (if used): For complex animations with JSON assets
- **Particle System Libraries**: For background visual effects

## Build System
- **Gradle**: Standard Android build system
- **Kotlin**: Primary programming language
- **Android Studio**: Development environment

## Runtime Permissions
- **INTERNET**: Network access for demo functionality
- **VIBRATE**: Haptic feedback on PIN keypad interactions
- **WAKE_LOCK**: Keep screen active during lock activity

The app is designed as a self-contained demonstration that doesn't integrate with external services or databases, focusing purely on showcasing Android UI capabilities and permission handling patterns.